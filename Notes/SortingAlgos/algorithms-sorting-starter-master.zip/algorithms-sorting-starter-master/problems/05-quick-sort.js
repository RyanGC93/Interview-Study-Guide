// Implement Quick Sort

function quickSort(array) {
  // your code here
}


module.exports = {
  quickSort
};
