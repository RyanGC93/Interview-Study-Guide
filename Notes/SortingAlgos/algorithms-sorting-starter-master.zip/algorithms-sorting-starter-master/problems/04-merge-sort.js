// Implement Merge Sort

function merge(array1, array2) {
  // your code here
}

function mergeSort(array) {
  // your code here
}

module.exports = {
  merge,
  mergeSort
};
