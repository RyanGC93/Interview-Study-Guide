// Implement Selection Sort

// Implement swap without looking at bubble sort
function swap(arr, index1, index2) {
  // your code here
}

function selectionSort(list) {
  // your code here
}

module.exports = {
  selectionSort,
  swap
};
