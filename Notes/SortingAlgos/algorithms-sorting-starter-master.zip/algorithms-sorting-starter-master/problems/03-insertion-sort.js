// Implement Insertion Sort

function insertionSort(list) {
  // your code here
}

module.exports = {
  insertionSort
};
