function myMin1a(list) {
  // Code goes here ...
}


function myMin1b(list) {
  // Code goes here ...
}


function myMin2(list) {
  // Code goes here ...
}


function largestContiguousSubsum1(array) {
  // Code goes here ...
}


function largestContiguousSubsum2(array) {
  // Code goes here ...
}
