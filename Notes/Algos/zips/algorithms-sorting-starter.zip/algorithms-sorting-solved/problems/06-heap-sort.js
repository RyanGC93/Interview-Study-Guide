// Implement Heap Sort

function heapSort(array) {
    // your code here
  }
  
  
  module.exports = {
    heapSort
  };
  