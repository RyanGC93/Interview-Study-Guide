/*********************************************************************
Work through this problem on https://leetcode.com/problems/minimum-path-sum/
and use the specs given there. Feel free to use this file for scratch work.
*********************************************************************/
