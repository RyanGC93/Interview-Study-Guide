/*********************************************************************
Work through this problem on https://leetcode.com/problems/climbing-stairs/
and use the specs given there. Feel free to use this file for scratch work.
*********************************************************************/
