// View the full problem and run the test cases at:
//  https://leetcode.com/problems/delete-node-in-a-bst/

function deleteNode(root, key) {

}