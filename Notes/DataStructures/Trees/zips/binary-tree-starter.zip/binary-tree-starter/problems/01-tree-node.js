
// Implement a class that takes a value
// and constructs a valid binary tree node
class TreeNode {
    // Your code here
}

module.exports = {
    TreeNode
};